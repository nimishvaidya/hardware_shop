/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hardware_shop;

import com.sun.javafx.applet.Splash;

/**
 *
 * @author abhic
 */
public class Screen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        splash Splash=new splash();
        Splash.setVisible(true);
        Login L=new Login();
        
        try {
            for(int i=0;i<=100;i++)
            {
              Thread.sleep(40);
              Splash.loadingnum.setText(Integer.toString(i)+"%");
              Splash.loadingbar.setValue(i);
              
              if(i==100)
              {
                  Splash.setVisible(false);
                  L.setVisible(true);
              }
                               
            }
            }
        catch (Exception e) {
        }
    }

    private static void setText(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
